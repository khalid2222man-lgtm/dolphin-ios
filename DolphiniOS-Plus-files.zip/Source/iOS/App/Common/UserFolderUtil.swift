// Copyright 2022 DolphiniOS Project
// SPDX-License-Identifier: GPL-2.0-or-later

import Foundation

@objc class UserFolderUtil: NSObject {
  @objc static func getUserFolder() -> String {
#if NONJAILBROKEN || TROLLSTORE
    return NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]
#else
    return "/private/var/mobile/Documents/DolphiniOS"
#endif
  }
  
  @objc static func getSoftwareFolder() -> String {
    return getUserFolder().stringByAppendingPathComponent("Software")
  }
}

// MARK: - External games folder (USB-C / SD card)
//
// DolphiniOS Plus: lets the user point the game list at a folder on external storage and read games
// in place. The Dolphin core opens files by POSIX path, so security-scoped access to the folder must stay
// active for the whole app session. Nothing is ever copied into the app sandbox.

@objc class ExternalStorageManager: NSObject {
  @objc static let shared = ExternalStorageManager()
  
  /// Posted on the main queue whenever the drive becomes available or unavailable.
  @objc static let statusChangedNotificationName = "DOLExternalStorageStatusChanged"
  
  private let bookmarkKey = "DOLExternalGamesFolderBookmark"
  private let nameKey = "DOLExternalGamesFolderName"
  
  private var scopedURL: URL?
  private var timer: Timer?
  private var wasAvailable = false
  private var probing = false
  private let probeQueue = DispatchQueue(label: "me.oatmealdome.dolphinios.external-storage", qos: .utility)
  
  @objc private(set) var isConfigured = false
  @objc private(set) var isAvailable = false
  @objc private(set) var volumeName: String = ""
  @objc private(set) var freeBytes: Int64 = -1
  
  /// Path to scan for games, or nil if no drive is configured or it is currently disconnected.
  @objc var availableFolderPath: String? {
    // Read from background queues by the game scanner, so guard it.
    pathLock.lock()
    defer { pathLock.unlock() }
    return publishedPath
  }
  
  private let pathLock = NSLock()
  private var publishedPath: String?
  
  /// Short human-readable state, suitable for a menu title.
  @objc var statusDescription: String {
    if !isConfigured { return "No folder selected" }
    if isAvailable {
      if freeBytes >= 0 {
        return "\(volumeName) (\(ByteCountFormatter.string(fromByteCount: freeBytes, countStyle: .file)) free)"
      }
      return volumeName
    }
    return "\(volumeName) - not connected"
  }
  
  // MARK: Lifecycle
  
  /// Call once at launch, before the first game scan.
  @objc func restore() {
    guard let data = UserDefaults.standard.data(forKey: bookmarkKey) else {
      isConfigured = false
      return
    }
    
    isConfigured = true
    volumeName = UserDefaults.standard.string(forKey: nameKey) ?? "External drive"
    resolve(bookmark: data)
    startMonitoring()
  }
  
  /// Call with the URL returned by a folder picker (opened in place, not as a copy).
  @objc func adoptPickedFolder(_ url: URL) -> Bool {
    guard url.startAccessingSecurityScopedResource() else {
      return false
    }
    
    stopAccess()
    scopedURL = url
    
    // On iOS a bookmark made from a picker URL is implicitly security-scoped.
    guard let data = try? url.bookmarkData(options: [], includingResourceValuesForKeys: nil, relativeTo: nil) else {
      return false
    }
    
    UserDefaults.standard.set(data, forKey: bookmarkKey)
    
    if let name = try? url.resourceValues(forKeys: [.volumeNameKey]).volumeName {
      volumeName = name
      UserDefaults.standard.set(name, forKey: nameKey)
    }
    
    isConfigured = true
    probeSynchronously()
    startMonitoring()
    
    return true
  }
  
  @objc func forgetFolder() {
    timer?.invalidate()
    timer = nil
    stopAccess()
    
    UserDefaults.standard.removeObject(forKey: bookmarkKey)
    UserDefaults.standard.removeObject(forKey: nameKey)
    
    isConfigured = false
    setAvailable(false)
  }
  
  // MARK: Internals
  
  private func resolve(bookmark data: Data) {
    var stale = false
    
    guard let url = try? URL(resolvingBookmarkData: data, options: [], relativeTo: nil, bookmarkDataIsStale: &stale) else {
      // The drive is not attached right now. Keep the bookmark and retry on the next tick.
      stopAccess()
      setAvailable(false)
      return
    }
    
    if scopedURL?.path != url.path {
      stopAccess()
    }
    
    if scopedURL == nil {
      if url.startAccessingSecurityScopedResource() {
        scopedURL = url
      } else {
        setAvailable(false)
        return
      }
    }
    
    if stale, let fresh = try? url.bookmarkData(options: [], includingResourceValuesForKeys: nil, relativeTo: nil) {
      UserDefaults.standard.set(fresh, forKey: bookmarkKey)
    }
    
    probeSynchronously()
  }
  
  private func stopAccess() {
    scopedURL?.stopAccessingSecurityScopedResource()
    scopedURL = nil
  }
  
  private func startMonitoring() {
    guard timer == nil else {
      return
    }
    
    // iOS has no public "volume unmounted" notification, so poll.
    timer = Timer.scheduledTimer(withTimeInterval: 2.0, repeats: true) { [weak self] _ in
      self?.tick()
    }
  }
  
  private func tick() {
    if scopedURL == nil, let data = UserDefaults.standard.data(forKey: bookmarkKey) {
      resolve(bookmark: data) // try to re-attach after a reconnect
    } else {
      probeAsynchronously()
    }
  }
  
  private static func probe(_ url: URL) -> (available: Bool, name: String?, free: Int64) {
    guard (try? url.checkResourceIsReachable()) == true,
          (try? FileManager.default.contentsOfDirectory(atPath: url.path)) != nil else {
      return (false, nil, -1)
    }
    
    let values = try? url.resourceValues(forKeys: [.volumeNameKey, .volumeAvailableCapacityForImportantUsageKey])
    return (true, values?.volumeName, values?.volumeAvailableCapacityForImportantUsage ?? -1)
  }
  
  private func probeSynchronously() {
    guard let url = scopedURL else {
      setAvailable(false)
      return
    }
    
    apply(Self.probe(url))
  }
  
  // Reads the directory off the main thread: touching a yanked drive can block.
  private func probeAsynchronously() {
    guard let url = scopedURL, !probing else {
      return
    }
    
    probing = true
    
    probeQueue.async { [weak self] in
      let result = Self.probe(url)
      
      DispatchQueue.main.async {
        self?.probing = false
        self?.apply(result)
      }
    }
  }
  
  private func apply(_ result: (available: Bool, name: String?, free: Int64)) {
    if let name = result.name, !name.isEmpty {
      volumeName = name
    }
    
    freeBytes = result.free
    setAvailable(result.available)
  }
  
  private func setAvailable(_ available: Bool) {
    let changed = available != wasAvailable
    
    isAvailable = available
    wasAvailable = available
    
    pathLock.lock()
    publishedPath = available ? scopedURL?.path : nil
    pathLock.unlock()
    
    if changed {
      NotificationCenter.default.post(name: Notification.Name(ExternalStorageManager.statusChangedNotificationName), object: self)
    }
  }
}
