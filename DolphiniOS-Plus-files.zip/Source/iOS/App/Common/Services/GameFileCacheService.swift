// Copyright 2022 DolphiniOS Project
// SPDX-License-Identifier: GPL-2.0-or-later

import UIKit

class GameFileCacheService : UIResponder, UIApplicationDelegate {
  func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
    // Re-attach the external games folder (if any) before the first scan.
    ExternalStorageManager.shared.restore()
    
    // Initiate a rescan of the Software directory.
    GameFileCacheManager.shared().rescan()
    
    return true
  }
}
